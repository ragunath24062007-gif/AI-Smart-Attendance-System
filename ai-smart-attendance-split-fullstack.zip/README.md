# AI Smart Attendance System — Split into Frontend & Backend

This project is now split into two independent folders, like two
separate mini-projects that talk to each other over the network:

```
split_project/
├── frontend/   → React + Vite website (what the user sees)
└── backend/    → Express API server (stores & serves data)
```

## Run order (important!)

**Step 1 — Start the backend first**
```bash
cd backend
npm install
npm run dev
```
Runs on http://localhost:3000

**Step 2 — Start the frontend in a NEW terminal window**
```bash
cd frontend
npm install
npm run dev
```
Runs on http://localhost:5173

Now open http://localhost:5173 in your browser. The website
(frontend) will fetch student/attendance/session data from the
server (backend) behind the scenes.

## Why two folders instead of one?
* `frontend/` = only the visual website code (React components, CSS, images)
* `backend/` = only the server code (API routes, data storage)
* They are connected by one small setting: `frontend/vite.config.ts`
  has a `proxy` rule that forwards any `/api/...` call to the backend.

This mirrors how real companies structure projects — frontend
developers and backend developers can work in their own folder
without touching each other's code.
